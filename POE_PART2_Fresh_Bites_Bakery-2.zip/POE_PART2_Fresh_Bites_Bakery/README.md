# Fresh Bites Bakery - Part 2

## Web Development (Introduction) - WEDE5020

This is the Part 2 update of the Fresh Bites Bakery website. Part 2 focuses on CSS styling, desktop layout and responsive design.

## Pages

- `index.html` - Home page
- `about.html` - About the bakery
- `products.html` - Products
- `enquiry.html` - Product enquiry
- `contact.html` - Contact details and two locations

## Part 2 Changes

The main changes made for Part 2 include:

- Added one external stylesheet in `css/style.css`.
- Added a basic CSS reset.
- Added a consistent colour scheme using cream, brown and orange.
- Added typography styles for headings, paragraphs and navigation.
- Used CSS Grid and Flexbox for the main layouts.
- Added cards, buttons, borders and shadows.
- Added hover and focus states for links and buttons.
- Added tablet and mobile media queries.
- Changed multi-column sections to single-column layouts on smaller screens.
- Used relative units such as `%`, `rem` and `clamp()`.
- Added responsive images using `picture`, `srcset` and `sizes` so images adjust to different screen sizes.
- Improved navigation so it changes layout on smaller screens.
- Kept the five-page structure from Part 1.

## Testing Evidence

The POE requires screenshots showing the website at desktop, tablet and mobile sizes. These screenshots must be taken from the student's own browser/developer tools after opening the website.

Suggested evidence:

1. Desktop - approximately 1366px wide.
2. Tablet - approximately 768px wide.
3. Mobile - approximately 390px wide.

Check that:
- The navigation remains usable.
- Text does not run off the screen.
- Cards stack correctly.
- Forms fit inside the page.
- Product sections do not overflow.
- Buttons and links remain easy to use.

## Changelog

### Part 2
- Added external CSS stylesheet.
- Added base styling and a reset for consistent browser rendering.
- Added typography and spacing styles.
- Added desktop grid and Flexbox layouts.
- Added bakery colour scheme and visual decoration.
- Added hover/focus states.
- Added tablet and mobile breakpoints.
- Adjusted navigation for smaller screens.
- Adjusted product cards and content grids for smaller screens.
- Added responsive sizing for headings and page content.
- Updated the README with Part 2 information and testing instructions.

### Part 1 Feedback

If formal lecturer feedback was received for Part 1, record it here together with the change made. Do not invent feedback.

- Lecturer feedback: [complete this line if feedback was received]
- Change made: [state the correction made]

## References

The following references were used as technical starting points. Exact image sources should be added if external images are later used.

Mozilla Developer Network (MDN) (n.d.) CSS: Cascading Style Sheets. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS (Accessed: 26 September 2026).

Mozilla Developer Network (MDN) (n.d.) CSS media queries. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries (Accessed: 26 September 2026).

World Wide Web Consortium (W3C) (n.d.) CSS specifications. Available at: https://www.w3.org/Style/CSS/ (Accessed: 26 September 2026).

World Wide Web Consortium (W3C) (n.d.) Markup Validation Service. Available at: https://validator.w3.org/ (Accessed: 26 September 2026).

Note: The IIE POE requires the README to be updated with new Part 2 references and the required referencing style. Image references should be added for any external images actually used.

## Responsive Design Testing Screenshots

The website should be tested at desktop, tablet and mobile screen sizes using Google Chrome Developer Tools. The screenshots below provide evidence of the responsive design testing required for Part 2.

### Desktop View

![Desktop View](screenshots/desktop-view.png)

### Tablet View

![Tablet View](screenshots/tablet-view.png)

### Mobile View

![Mobile View](screenshots/mobile-view.png)

**Screenshot evidence reminder:** Take these screenshots yourself in Chrome Developer Tools/device mode. Do not submit placeholder or edited screenshots as evidence.


## AI Use Disclosure

AI tools were used to assist with drafting, checking and improving parts of the website code and documentation. The student should review and test the final work before submission and disclose AI use according to the IIE requirements.


### Supplied Mobile Browser Check

The supplied screenshot is saved as `screenshots/mobile-browser-check.jpg`. It shows the page opened on a mobile device. Because the screenshot was taken while the external CSS was not being loaded by the mobile file viewer, it is kept as a supporting browser check and should not replace the final responsive mobile evidence screenshot.

For the final evidence, open the extracted project folder in Chrome so that `css/style.css` loads, then take a fresh mobile screenshot.
