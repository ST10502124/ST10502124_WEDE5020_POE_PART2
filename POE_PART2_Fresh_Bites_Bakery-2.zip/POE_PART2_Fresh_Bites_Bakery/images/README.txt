Images in this folder were created for the Fresh Bites Bakery Part 2 project. They are original project assets.

Responsive image variants use small and large files with srcset and sizes in the HTML.
