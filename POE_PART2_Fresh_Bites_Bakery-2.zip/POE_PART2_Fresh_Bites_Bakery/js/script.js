// JavaScript is reserved for Part 3 functionality.
// Part 2 mainly focuses on CSS styling and responsive design.
